import os
import time

time.sleep(5)
os.startfile("bot.py")
time.sleep(2)
quit()
# really, that's all that is in this script. lol.
